/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 */
package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class ReverseStep
extends Module {
    private final Setting<Boolean> twoBlocks = this.register(new Setting<Boolean>("2Blocks", Boolean.FALSE));
    private static ReverseStep INSTANCE = new ReverseStep();

    public ReverseStep() {
        super("ReverseStep", "ReverseStep.", Module.Category.MOVEMENT, true, false, false);
        this.setInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public static ReverseStep getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ReverseStep();
        }
        return INSTANCE;
    }

    @Override
    public void onUpdate() {
        if (ReverseStep.fullNullCheck()) {
            return;
        }
        IBlockState touchingState = ReverseStep.mc.field_71441_e.func_180495_p(new BlockPos(ReverseStep.mc.field_71439_g.field_70165_t, ReverseStep.mc.field_71439_g.field_70163_u, ReverseStep.mc.field_71439_g.field_70161_v).func_177979_c(2));
        IBlockState touchingState2 = ReverseStep.mc.field_71441_e.func_180495_p(new BlockPos(ReverseStep.mc.field_71439_g.field_70165_t, ReverseStep.mc.field_71439_g.field_70163_u, ReverseStep.mc.field_71439_g.field_70161_v).func_177979_c(3));
        if (ReverseStep.mc.field_71439_g.func_180799_ab() || ReverseStep.mc.field_71439_g.func_70090_H()) {
            return;
        }
        if (touchingState.func_177230_c() == Blocks.field_150357_h || touchingState.func_177230_c() == Blocks.field_150343_Z) {
            if (ReverseStep.mc.field_71439_g.field_70122_E) {
                ReverseStep.mc.field_71439_g.field_70181_x -= 1.0;
            }
        } else if ((this.twoBlocks.getValue().booleanValue() && touchingState2.func_177230_c() == Blocks.field_150357_h || this.twoBlocks.getValue().booleanValue() && touchingState2.func_177230_c() == Blocks.field_150343_Z) && ReverseStep.mc.field_71439_g.field_70122_E) {
            ReverseStep.mc.field_71439_g.field_70181_x -= 1.0;
        }
    }
}

