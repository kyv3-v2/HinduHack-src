/*
 * Decompiled with CFR 0.150.
 */
package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;

public class Flight
extends Module {
    public Flight() {
        super("Flight", "Flight.", Module.Category.MOVEMENT, true, false, false);
    }
}

