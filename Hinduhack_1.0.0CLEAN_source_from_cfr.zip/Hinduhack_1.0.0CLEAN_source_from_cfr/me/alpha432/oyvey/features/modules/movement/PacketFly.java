/*
 * Decompiled with CFR 0.150.
 */
package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;

public class PacketFly
extends Module {
    public PacketFly() {
        super("PacketFly", "PacketFly.", Module.Category.MOVEMENT, true, false, false);
    }
}

