/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 */
package me.alpha432.oyvey.features.modules.combat;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.BlockUtil;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class SelfFill
extends Module {
    private final Setting<Boolean> packet = this.register(new Setting<Boolean>("PacketPlace", Boolean.FALSE));

    public SelfFill() {
        super("SelfFill", "SelfFills yourself in a hole.", Module.Category.COMBAT, true, false, true);
    }

    @Override
    public void onEnable() {
        SelfFill.mc.field_71439_g.func_70664_aZ();
        SelfFill.mc.field_71439_g.func_70664_aZ();
    }

    @Override
    public void onUpdate() {
        BlockPos pos = new BlockPos(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u, SelfFill.mc.field_71439_g.field_70161_v);
        if (SelfFill.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150350_a && BlockUtil.isPositionPlaceable(pos.func_177977_b(), false) == 3) {
            BlockUtil.placeBlock(pos.func_177977_b(), EnumHand.MAIN_HAND, false, this.packet.getValue(), false);
        }
        if (SelfFill.mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150343_Z) {
            SelfFill.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u - 1.3, SelfFill.mc.field_71439_g.field_70161_v, false));
            SelfFill.mc.field_71439_g.func_70107_b(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u - 1.3, SelfFill.mc.field_71439_g.field_70161_v);
            this.toggle();
        }
    }
}

