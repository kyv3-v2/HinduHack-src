/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelEnderCrystal
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.entity.Render
 *  net.minecraft.client.renderer.entity.RenderDragon
 *  net.minecraft.client.renderer.entity.RenderEnderCrystal
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  org.lwjgl.opengl.GL11
 */
package me.alpha432.oyvey.mixin.mixins;

import javax.annotation.Nullable;
import me.alpha432.oyvey.features.modules.client.ClickGui;
import me.alpha432.oyvey.features.modules.render.Wireframe;
import me.alpha432.oyvey.util.ColorUtil;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelEnderCrystal;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderDragon;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={RenderEnderCrystal.class})
public class MixinRenderEnderCrystal
extends Render<EntityEnderCrystal> {
    @Shadow
    private static final ResourceLocation field_110787_a = new ResourceLocation("textures/entity/endercrystal/endercrystal.png");
    @Shadow
    private final ModelBase field_76995_b = new ModelEnderCrystal(0.0f, true);
    @Shadow
    private final ModelBase field_188316_g = new ModelEnderCrystal(0.0f, false);

    protected MixinRenderEnderCrystal(RenderManager renderManager) {
        super(renderManager);
    }

    @Overwrite
    public void func_76986_a(EntityEnderCrystal entity, double x, double y, double z, float entityYaw, float partialTicks) {
        float f = (float)entity.field_70261_a + partialTicks;
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)((float)x), (float)((float)y), (float)((float)z));
        this.func_110776_a(field_110787_a);
        float f1 = MathHelper.func_76126_a((float)(f * 0.2f)) / 2.0f + 0.5f;
        f1 += f1 * f1;
        if (this.field_188301_f) {
            GlStateManager.func_179142_g();
            GlStateManager.func_187431_e((int)this.func_188298_c((Entity)entity));
        }
        if (Wireframe.getINSTANCE().isOn() && Wireframe.getINSTANCE().crystals.getValue().booleanValue()) {
            float red = (float)ClickGui.getInstance().red.getValue().intValue() / 255.0f;
            float green = (float)ClickGui.getInstance().green.getValue().intValue() / 255.0f;
            float blue = (float)ClickGui.getInstance().blue.getValue().intValue() / 255.0f;
            if (Wireframe.getINSTANCE().cMode.getValue().equals((Object)Wireframe.RenderMode.WIREFRAME) && Wireframe.getINSTANCE().crystalModel.getValue().booleanValue()) {
                this.field_188316_g.func_78088_a((Entity)entity, 0.0f, f * 3.0f, f1 * 0.2f, 0.0f, 0.0f, 0.0625f);
            }
            GlStateManager.func_179094_E();
            GL11.glPushAttrib((int)1048575);
            if (Wireframe.getINSTANCE().cMode.getValue().equals((Object)Wireframe.RenderMode.WIREFRAME)) {
                GL11.glPolygonMode((int)1032, (int)6913);
            }
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2896);
            if (Wireframe.getINSTANCE().cMode.getValue().equals((Object)Wireframe.RenderMode.WIREFRAME)) {
                GL11.glEnable((int)2848);
            }
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
            GL11.glColor4f((float)(ClickGui.getInstance().rainbow.getValue() != false ? (float)ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRed() / 255.0f : red), (float)(ClickGui.getInstance().rainbow.getValue() != false ? (float)ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getGreen() / 255.0f : green), (float)(ClickGui.getInstance().rainbow.getValue() != false ? (float)ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getBlue() / 255.0f : blue), (float)(Wireframe.getINSTANCE().cAlpha.getValue().floatValue() / 255.0f));
            if (Wireframe.getINSTANCE().cMode.getValue().equals((Object)Wireframe.RenderMode.WIREFRAME)) {
                GL11.glLineWidth((float)Wireframe.getINSTANCE().crystalLineWidth.getValue().floatValue());
            }
            this.field_188316_g.func_78088_a((Entity)entity, 0.0f, f * 3.0f, f1 * 0.2f, 0.0f, 0.0f, 0.0625f);
            GL11.glDisable((int)2896);
            GL11.glEnable((int)2929);
            GL11.glDepthMask((boolean)true);
            GL11.glColor4f((float)(ClickGui.getInstance().rainbow.getValue() != false ? (float)ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRed() / 255.0f : red), (float)(ClickGui.getInstance().rainbow.getValue() != false ? (float)ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getGreen() / 255.0f : green), (float)(ClickGui.getInstance().rainbow.getValue() != false ? (float)ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getBlue() / 255.0f : blue), (float)(Wireframe.getINSTANCE().cAlpha.getValue().floatValue() / 255.0f));
            if (Wireframe.getINSTANCE().cMode.getValue().equals((Object)Wireframe.RenderMode.WIREFRAME)) {
                GL11.glLineWidth((float)Wireframe.getINSTANCE().crystalLineWidth.getValue().floatValue());
            }
            this.field_188316_g.func_78088_a((Entity)entity, 0.0f, f * 3.0f, f1 * 0.2f, 0.0f, 0.0f, 0.0625f);
            GlStateManager.func_179126_j();
            GlStateManager.func_179099_b();
            GlStateManager.func_179121_F();
        } else {
            this.field_188316_g.func_78088_a((Entity)entity, 0.0f, f * 3.0f, f1 * 0.2f, 0.0f, 0.0f, 0.0625f);
        }
        if (this.field_188301_f) {
            GlStateManager.func_187417_n();
            GlStateManager.func_179119_h();
        }
        GlStateManager.func_179121_F();
        BlockPos blockpos = entity.func_184518_j();
        if (blockpos != null) {
            this.func_110776_a(RenderDragon.field_110843_g);
            float f2 = (float)blockpos.func_177958_n() + 0.5f;
            float f3 = (float)blockpos.func_177956_o() + 0.5f;
            float f4 = (float)blockpos.func_177952_p() + 0.5f;
            double d0 = (double)f2 - entity.field_70165_t;
            double d1 = (double)f3 - entity.field_70163_u;
            double d2 = (double)f4 - entity.field_70161_v;
            RenderDragon.func_188325_a((double)(x + d0), (double)(y - 0.3 + (double)(f1 * 0.4f) + d1), (double)(z + d2), (float)partialTicks, (double)f2, (double)f3, (double)f4, (int)entity.field_70261_a, (double)entity.field_70165_t, (double)entity.field_70163_u, (double)entity.field_70161_v);
        }
        super.func_76986_a((Entity)entity, x, y, z, entityYaw, partialTicks);
    }

    @Nullable
    protected ResourceLocation getEntityTexture(EntityEnderCrystal entityEnderCrystal) {
        return null;
    }
}

