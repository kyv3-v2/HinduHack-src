/*
 * Decompiled with CFR 0.150.
 */
package org.spongepowered.tools.obfuscation.interfaces;

import javax.lang.model.element.Element;

public interface IJavadocProvider {
    public String getJavadoc(Element var1);
}

