/*
 * Decompiled with CFR 0.150.
 */
package org.spongepowered.tools.obfuscation.interfaces;

public interface IOptionProvider {
    public String getOption(String var1);
}

