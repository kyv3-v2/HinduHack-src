/*
 * Decompiled with CFR 0.150.
 */
package org.spongepowered.asm.service;

public interface ITransformer {
}

