/*
 * Decompiled with CFR 0.150.
 */
package org.spongepowered.asm.util;

public interface ITokenProvider {
    public Integer getToken(String var1);
}

