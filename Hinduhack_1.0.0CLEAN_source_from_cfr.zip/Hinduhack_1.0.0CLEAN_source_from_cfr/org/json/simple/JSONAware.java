/*
 * Decompiled with CFR 0.150.
 */
package org.json.simple;

public interface JSONAware {
    public String toJSONString();
}

