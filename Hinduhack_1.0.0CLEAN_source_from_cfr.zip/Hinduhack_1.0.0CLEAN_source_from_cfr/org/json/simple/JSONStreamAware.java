/*
 * Decompiled with CFR 0.150.
 */
package org.json.simple;

import java.io.IOException;
import java.io.Writer;

public interface JSONStreamAware {
    public void writeJSONString(Writer var1) throws IOException;
}

